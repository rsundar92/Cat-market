import "destyle.css";

import "./App.css";
import CatMarket from "./CatMarket";

function App() {
  return (
    <div className="App">
      <CatMarket />
    </div>
  );
}

export default App;
